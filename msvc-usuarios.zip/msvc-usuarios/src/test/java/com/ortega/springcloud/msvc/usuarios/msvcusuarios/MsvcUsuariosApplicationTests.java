package com.ortega.springcloud.msvc.usuarios.msvcusuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsvcUsuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
